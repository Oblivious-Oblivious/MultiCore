int main(void)
{
	void *v = nullptr;

	return v ? 1 : 0;
}
